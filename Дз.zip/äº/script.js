/**  Получить ссылку на элемент кнопки по его ID
 * @type {HTMLButtonElement}
 */
 let button = document.querySelector("#Button");
 // Проверить, что кнопку удалось получить (не null)
 if (button) {
     // Для этой кнопки установить событие на клик мыши
     button.onclick = createWindow;
 }
 // Переменная-счетчик необходима для установки позиции по оси Z активного окна
 // чтобы активное окно было всегда повех всех остальных
 let zIndex = 1;
 /**
  * Создание нового окна
  * @param {MouseEvent} event
  */
 function createWindow(event) {
      
 
     let rootWindow = document.createElement("div"),
         head = document.createElement("div"),
         body = document.createElement("div"),
         headerText = document.createElement("div"),
         close = document.createElement("div"),
         folding = document.createElement("div"),
         win = document.createElement("div");
 
     rootWindow.append(head, body);
     head.append(headerText, folding, close, win);
     

      
     let a = document.createElement("a");

     a.href = "https://yandex.ru/";
     a.innerHTML="Яндекс";
     

     body.append(a);

     a.className="a";
     // События на заголовок для перемещения окна
     head.onmousedown = onMouseDown;
     head.onmousemove = onMouseMove;
     head.onmouseup = onMouseUp;
 
     headerText.textContent = "Window";
 
     rootWindow.className = "window";
     head.className = "head";
     body.className = "body";
     close.className = "close";
     folding.className = "folding";
     win.className = "win";
     // Событие на кнопку "Закрыть"
     close.onclick = closeWindow; 
     folding.onclick = closeWindow;
     win.onclick = winWindow;
     // Добавить созданное окно в конец тела страницы
     document.body.append(rootWindow);
 }
 /**
  * @param {MouseEvent} event
  */
 function closeWindow(event) {
     // Для закрытия окна получаем родительский элемент текущего
     // элемента (т.е. кнопки закрыть) с классом .window
     let thisWindow = this.closest(".window");
     if (thisWindow) {
         // И если его нашли - удаляем
         thisWindow.remove();
     }
 }
 // сворачиваем эту штуку
 /**
  * @param {MouseEvent} event 
 */
 function foldingWindow(event)
 {
     let thisWindow = this.closest(".window");
     if (thisWindow)
     {
        thisWindow.body();
     }
 }
 // разернуть окно
 


let i=0;
 /**
  * @param {MouseEvent} event
  */
  function winWindow(event) {
    let thisWindow = this.closest(".window");
    if (thisWindow) {
        
        if(i%2==0)
        {
        thisWindow.style.height='1080px';
        thisWindow.style.width='1920px';
        thisWindow.style.top='0px';
        thisWindow.style.left='0px';
        i++;
        this.dataset.isMove = "false";
        /**я вам запрещаю перемещать окно! */
        }
        else 
        {
        thisWindow.style.height='500px';
        thisWindow.style.width='500px';
        thisWindow.style.top='10px';
        thisWindow.style.left='120px';
        i++;
        }
    }
}
 
 /**
  * @param {MouseEvent} event
  */
 function onMouseDown(event) {
     // Установить флажок на текущее окно, говоря, что его можно перемещать
     // Событие onmousemove будет работать для этого элемента, если значение "true
     if(i%2==0)
     {
     this.dataset.isMove = "true";
     // Сохранить текущую позицию мыши, чтобы потом найти разницу между предыдущей
     // и текущей позицией мыши
     this.dataset.x = "" + event.clientX;
     this.dataset.y = "" + event.clientY;
     // Установить на текущее окно позицию по оси Z выше, чем у кого-либо
     this.parentElement.style.zIndex = "" + (zIndex++);
     }
 }
 /**
  * @param {MouseEvent} event
  */
 function onMouseUp(event) {
     this.dataset.isMove = "false";
 }
 /**
  * @param {MouseEvent} event
  */
 function onMouseMove(event) {
     if (this.dataset.isMove !== "true") return;
 
     // Разница позиции курсора текущего кадра с предыдущим
     let x = event.clientX - +this.dataset.x;
     let y = event.clientY - +this.dataset.y;
 
     let bound = this.parentElement.getBoundingClientRect();
 
     this.parentElement.style.left = `${bound.left + x}px`;
     this.parentElement.style.top = `${bound.top + y}px`;
 
     this.dataset.x = "" + event.clientX;
     this.dataset.y = "" + event.clientY;
 }
 
 